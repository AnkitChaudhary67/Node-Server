var http = require("http");

const httpServer = http.createServer(handleServer);


function handleServer(req, res) {
  
}

module.exports = httpServer;